/*
 * The class for running
 */

package graphs;

public class Program {

	public static void main(String[] args) {
		GUI graphsFrame = new GUI();
	
	}

}
